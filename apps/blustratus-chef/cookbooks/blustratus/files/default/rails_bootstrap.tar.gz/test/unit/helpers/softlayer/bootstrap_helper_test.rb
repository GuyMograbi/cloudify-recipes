require 'test_helper'

class Softlayer::BootstrapHelperTest < ActionView::TestCase
end
