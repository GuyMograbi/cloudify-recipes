require 'test_helper'

class Softlayer::BootstrapControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
