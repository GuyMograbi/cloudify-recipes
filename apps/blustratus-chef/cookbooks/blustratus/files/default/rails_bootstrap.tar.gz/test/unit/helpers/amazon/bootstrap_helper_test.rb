require 'test_helper'

class BootstrapHelperTest < ActionView::TestCase
end
