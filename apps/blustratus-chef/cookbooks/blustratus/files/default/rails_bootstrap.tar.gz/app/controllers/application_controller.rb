class ApplicationController < ActionController::Base
  protect_from_forgery
  before_filter :set_locale

  def index
    case ENV['CLOUD_PROVIDER']
    when 'AWS'
      redirect_to controller: 'amazon/bootstrap', action: 'index'
      return
    when 'SOFTLAYER'
      redirect_to controller: 'softlayer/bootstrap', action: 'index'
      return
    end

    render text: <<-EOH
      <p>ERROR: No cloud service specified in CLOUD_PROVIDER environment variable. Possible values are:</p>
      <ul>
        <li>AWS (Amazon)</li>
        <li>SOFTLAYER (SoftLayer)</li>
      </ul>
    EOH
  end

  def logout
    session.delete :authenticated
    session.delete :username
    session.delete :access_key
    $redis.del('session_id')

    redirect_to root_path
  end

  private
  def set_locale
    I18n.locale = params[:locale] || I18n.default_locale
  end
end
