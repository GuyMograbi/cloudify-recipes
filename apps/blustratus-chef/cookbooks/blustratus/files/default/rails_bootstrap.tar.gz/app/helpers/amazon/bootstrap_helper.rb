module Amazon::BootstrapHelper
end
