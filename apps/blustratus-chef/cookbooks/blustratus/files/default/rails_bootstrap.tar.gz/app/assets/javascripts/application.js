// This is a manifest file that'll be compiled into application.js, which will include all the files
// listed below.
//
// Any JavaScript/Coffee file within this directory, lib/assets/javascripts, vendor/assets/javascripts,
// or vendor/assets/javascripts of plugins, if any, can be referenced here using a relative path.
//
// It's not advisable to add code directly here, but if you do, it'll appear at the bottom of the
// the compiled file.
//
// WARNING: THE FIRST BLANK LINE MARKS THE END OF WHAT'S TO BE PROCESSED, ANY BLANK LINE SHOULD
// GO AFTER THE REQUIRES BELOW.
//
//= require jquery
//= require jquery_ujs
//= require_tree .
$(function() {
	$('.button-skip-step').click(function() {
		if (window.confirm(I18n.skip_module.confirmation)) {
			window.location = this.getAttribute('data-target');
		}
	});

	$('.button-restart-module').click(function() {
		window.location = this.getAttribute('data-target');
	});

	$('.js-next').click(function() {
		$this = $(this);
		$this.attr('disabled','disabled');
		window.location = this.getAttribute('data-target');
	});

	$('.js-prev').click(function() {
		var $form = $('form');
		
		if ($form) {
			$form.attr('action', this.getAttribute('data-target'));
			$form.prepend('<input type="hidden" name="back" value="true" />');
			$form.submit();
		}
	});

	$('.js-refresh').click(function() {
		location.reload(true);
	});
});