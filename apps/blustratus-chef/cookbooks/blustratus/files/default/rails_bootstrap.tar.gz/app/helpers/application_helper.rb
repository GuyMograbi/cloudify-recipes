module ApplicationHelper

    def menu_item link_text, link_path
      link_class = (request.original_url.end_with? link_path) ? 'active' : ''
      content_tag :li, link_text, class: link_class
    end

  def current_translations
    @translations ||= I18n.backend.send(:translations)
    @translations[I18n.locale].with_indifferent_access if !@translations[I18n.locale].nil?
  end

  def left_menu
    case ENV['CLOUD_PROVIDER']
    when 'AWS'
      render partial: 'shared/amazon_left_menu'
    when 'SOFTLAYER'
      render partial: 'shared/softlayer_left_menu'
    end
  end
end
