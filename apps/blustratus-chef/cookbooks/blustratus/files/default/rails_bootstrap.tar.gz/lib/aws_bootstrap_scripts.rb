module AwsBootstrapScripts

  module EC2
    def self.instance_id
      return `wget -q -O - http://169.254.169.254/latest/meta-data/instance-id`
    end

    def self.availability_zone
      return `wget -q -O - http://169.254.169.254/latest/meta-data/placement/availability-zone`
    end

    def self.ec2_object access_key, secret_key
      availability_zone = EC2.availability_zone
      region = availability_zone[0..-2]

      AWS.config(:access_key_id => access_key, :secret_access_key => secret_key, :region => region)
      return AWS::EC2.new()
    end
  end

  def self.validate_credentials access_key, secret_key
    instance_id = EC2.instance_id
    ec2 = EC2.ec2_object(access_key, secret_key)
    instance = ec2.instances[instance_id]

    begin
      instance.launch_time
    rescue AWS::EC2::Errors::AuthFailure => e
      return false
    rescue => e
      return false
    end

    return true
  end

  def self.create_from_snapshot_and_attach_ebs access_key, secret_key, params
    size        = params[:size].to_i
    device      = params[:device]
    snapshot_id = params[:snapshot_id]

    instance_id = EC2.instance_id
    availability_zone = EC2.availability_zone
    ec2 = EC2.ec2_object(access_key, secret_key)

    snapshot = ec2.snapshots[snapshot_id]

    volume = ec2.volumes.create(:size => size, :availability_zone => availability_zone, :snapshot => snapshot)
    instance = ec2.instances[instance_id]

    sleep 1 until volume.status == :available

    puts [volume.id, volume.size, volume.availability_zone_name, volume.status, volume.create_time.to_s].join("\t")

    attachment = volume.attach_to(instance, device)
    sleep 1 until attachment.status != :attaching

    puts [volume.id, instance_id, device, attachment.status, attachment.attach_time.to_s].join("\t")
  end

  def self.mount_ebs params
    require 'fileutils'

    device      = params[:device]
    mount_point = params[:mount_point]
    format      = params[:format]

    Dir.mkdir(mount_point) unless File.exists? mount_point
    FileUtils.chown_R 'db2inst1', 'db2iadm1', mount_point

    if format
      `mkfs.xfs -f #{device}`
    end

    escaped_device = device.gsub("/","\\/")
    `sed -i '/#{escaped_device}/d' /etc/fstab`

    `echo "#{device} #{mount_point} xfs defaults,noatime,nodiratime 0 0" >> /etc/fstab`
    `mount #{mount_point}`
  end

  def self.create_and_attach_ebs access_key, secret_key, params
    size     = params[:size].to_i
    device   = params[:device]
    wantiops = params[:want_iops]
    iops     = params[:iops].to_i

    instance_id = EC2.instance_id
    availability_zone = EC2.availability_zone
    ec2 = EC2.ec2_object(access_key, secret_key)

    volume_params = { :size => size, :availability_zone => availability_zone }
    if wantiops
      volume_params[:volume_type] = "io1"
      volume_params[:iops] = iops
    end

    volume = ec2.volumes.create(volume_params)
    sleep 1 until volume.status == :available

    puts [volume.id, volume.size, volume.availability_zone_name, volume.status, volume.create_time.to_s].join("\t")

    instance = ec2.instances[instance_id]
    attachment = volume.attach_to(instance, device)
    sleep 1 until attachment.status != :attaching

    puts [volume.id, instance_id, device, attachment.status, attachment.attach_time.to_s].join("\t")
  end

  def self.list_connected_ebs access_key, secret_key, params
    device = params[:device]

    instance_id = EC2.instance_id
    availability_zone = EC2.availability_zone
    ec2 = EC2.ec2_object(access_key, secret_key)

    instance = ec2.instances[instance_id]
    devices = device.split(",")

    volumes = instance.block_devices.delete_if { |bd| !devices.include?( bd[:device_name] ) }

    output = []
    volumes.each do |volume|
      output << {
        volume_id: volume[:ebs][:volume_id],
        instance_id: instance_id,
        device: availability_zone,
        status: volume[:ebs][:status],
        creation_time: volume[:ebs][:attach_time]
      }
    end

    return output
  end

  def self.list_ebs access_key, secret_key
    availability_zone = EC2.availability_zone
    ec2 = EC2.ec2_object(access_key, secret_key)

    vols = []
    ec2.volumes.each { |v| vols << v if v.availability_zone.name == availability_zone }

    return vols
  end

  def self.attach_ebs access_key, secret_key, params
    volume_id = params[:volume_id]
    device    = paramas[:device]

    instance_id = EC2.instance_id
    ec2 = EC2.ec2_object(access_key, secret_key)

    instance = ec2.instances[instance_id]
    volume = ec2.volumes[volume_id]

    attachment = volume.attach_to(instance, device)
    sleep 1 until attachment.status != :attaching

    return {
      volume_id: volume_id,
      instance_id: instance_id,
      device: device,
      status: attachment.status,
      attachment_time: attachment.attach_time
    }
  end
end